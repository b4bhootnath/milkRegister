<?php

include "header.php";
include "sidebar.php";
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">All Customer</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">All Customer</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Customer List</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>S. No.</th>
                    <th>Name</th>
                    <th>Father Name</th>
                    <th>Mobile</th>
                    
                  </tr>
                  </thead>
                  <tbody>

                  <?php
                  $sno = 1;

                  $sql = "Select * From customer";
                  $result = mysqli_query($con,$sql);
                  if(mysqli_affected_rows($con) !=0){
                      while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                          $name = $row['name'];
                          $fname = $row['fname'];
                          $mobile = $row['mobile'];

                          echo "<tr>";
                          echo "<td>".$sno."</td>";
                          echo "<td>".$name."</td>";
                          echo "<td>".$fname."</td>";
                          echo "<td>".$mobile."</td>";


                          echo "</tr>";


                          $sno++;

                      }

                  }

                  ?>
                 
                  
                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>





      


      
          
            </div>
            </div>

        
        
        </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
    
  <?php
include "footer.php";
  ?>