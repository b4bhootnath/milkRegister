$('#addRecord').click(function(){
    $('#recordModal').modal('show');
    $('#recordForm')[0].reset();
    $('.modal-title').html("<i class='fa fa-plus'></i> Add Record");
    $('#action').val('addRecord');
    $('#save').val('Add');
});		