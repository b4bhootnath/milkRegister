<?php

include "header.php";
include "sidebar.php";
?>

<?php

if($_POST['customer_id'] && $_POST['from_date'] && $_POST['to_date']){
    $customer_id = $_POST['customer_id'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    
    $f_date = date('d-m-Y',strtotime($from_date));
    $t_date = date('d-m-Y',strtotime($to_date));
    $query = mysqli_query($con,"Select * from customer where id='$customer_id'");
    //echo $query;
    if(mysqli_affected_rows($con) !=0){
        while($row = mysqli_fetch_array($query,MYSQLI_ASSOC)){
            $name = $row['name'];
            $fname = $row['fname'];
            $mobile = $row['mobile'];
        }
    }

}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Report</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Report</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-globe"></i> Vikas Diary
                   
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  Customer <br>
                  
                    <strong>Name : <?php echo $name; ?></strong><br>
                    <strong>Father Name : <?php echo $fname; ?></strong><br>
                    <strong>Mobile : <?php echo $mobile; ?></strong><br>
                    
                  
                </div>
                <div class="col-sm-4 invoice-col">
                  From Date : <br>
                  
                    <strong>Date : <?php echo $f_date; ?></strong><br>
                    
                  
                </div>
                <div class="col-sm-4 invoice-col">
                  To Date <br>
                  
                    <strong>Date : <?php echo $t_date; ?></strong><br>
                    
                  
                </div>
                
                <!-- /.col -->
                
                <!-- /.col -->
                
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Date</th>
                      <th>Qty</th>
                      <th>Fat</th>
                      <th>Rate</th>
                      <th>Session</th>
                      <th>Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                  

                  $sql = "Select * From milk where customer_id='$customer_id' AND date BETWEEN '$from_date' AND '$to_date' ORDER BY date ASC";
                  $result = mysqli_query($con,$sql);
                  if(mysqli_affected_rows($con) !=0){
                      while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                          $qty = $row['qty'];
                          $fat = $row['fat'];
                          $rate = $row['rate'];
                          $date =date('d-m-Y',strtotime($row['date']));
                          $session = $row['session'];
                          $am = (floatval($qty)*floatval($fat)*floatval($rate))/100;
                          $amount = round($am,2);
                          $sum += $amount;

                              

                  ?>

                  <tr>
                  <td><?php echo $date; ?></td>
                      <td><?php echo $qty; ?></td>
                      <td><?php echo $fat; ?></td>
                      <td><?php echo $rate; ?></td>
                      <td><?php echo $session; ?></td>
                      <td>Rs. <?php echo $amount; ?></td>
                      
                      
                     

                  </tr>



                <?php



                    

                    }

                }

                ?>
                    
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                 
                  

                  
                </div>
                <!-- /.col -->
                <div class="col-6">
                  

                  <div class="table-responsive">
                    <table class="table">
                     
                      <tr>
                        <th>Total:</th>
                        <td>Rs. <?php echo $sum; ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                  <a href="invoice-print.html" rel="noopener" target="_blank" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                  <button type="button" class="btn btn-success float-right"><i class="far fa-credit-card"></i> Submit
                    Payment
                  </button>
                  <button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                    <i class="fas fa-download"></i> Generate PDF
                  </button>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  <?php
include "footer.php";
  ?>