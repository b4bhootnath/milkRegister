<?php

include "header.php";
include "sidebar.php";
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Generate report</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Generate Report</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      <div class="row">


      <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Report</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST" action="report.php">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Customer Name</label>
                    <select name="customer_id" class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option selected="selected" data-select2-id="0"><--Select--></option>
                    <?php
                  

                  $sql = "Select * From customer";
                  $result = mysqli_query($con,$sql);
                  if(mysqli_affected_rows($con) !=0){
                      while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                          $id = $row['id'];
                          $name = $row['name'];
                          $fname = $row['fname'];
                         
                      
                  ?>

                    <option value="<?php echo $id; ?>" data-select2-id="<?php echo $id; ?>"><?php echo $name; ?> S/O <?php echo $fname; ?></option>
                    

                    <?php
                        }

                        }



                    ?>
                  </select>
                  </div>
                  
                 
                  <div class="form-group">
                    <label for="exampleInputPassword1">From Date</label>
                    <input type="date" name="from_date"  class="form-control"  required="required" >
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">To Date</label>
                    <input type="date" name="to_date"  class="form-control"  required="required" >
                  </div>
                  
                  
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="submit" class="btn btn-primary">Generate</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

            <!-- general form elements -->
           

            <!-- Input addon -->
           
            

          </div>
          
        </div><!-- /.row -->


        
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
    

  <?php
include "footer.php";
  ?>