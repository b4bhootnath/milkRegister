<?php
session_start();
unset($_SESSION["logged"]); 
unset($_SESSION["user_data"]); 
header("Location: ../login/index.php");

?>