<?php

include "header.php";
include "sidebar.php";
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Milk register</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Milk register</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      <div class="row">


      <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Milk</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST" action="">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Customer Name</label>
                    <select name="customer_id" class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                    <option selected="selected" data-select2-id="0"><--Select--></option>
                    <?php
                  

                  $sql = "Select * From customer";
                  $result = mysqli_query($con,$sql);
                  if(mysqli_affected_rows($con) !=0){
                      while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                          $id = $row['id'];
                          $name = $row['name'];
                          $fname = $row['fname'];
                         
                      
                  ?>

                    <option value="<?php echo $id; ?>" data-select2-id="<?php echo $id; ?>"><?php echo $name; ?> S/O <?php echo $fname; ?></option>
                    

                    <?php
                        }

                        }



                    ?>
                  </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Qty</label>
                    <input type="number" name="qty" class="form-control" id="exampleInputPassword1" required="required" placeholder="Enter Qty">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Fat</label>
                    <input type="number" name="fat" class="form-control" id="exampleInputPassword1" required="required" placeholder="Fat">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Rate</label>
                    <input type="number" name="rate" class="form-control" id="exampleInputPassword1" required="required" placeholder="Rate">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Date</label>
                    <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" class="form-control"  required="required" >
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Session</label>
                    <select name="session" class="form-control" id="">
                      <option value="Morning">Morning</option>
                      <option value="Evening">Evening</option>

                  </select>
                  
                  </div>
                  
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

            <!-- general form elements -->
           

            <!-- Input addon -->
           
            

          </div>
          
        </div><!-- /.row -->


        
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
    <?php
    if(isset($_POST['submit'])){
        $customer_id = $_POST['customer_id'];
        $qty = $_POST['qty'];
        $fat = $_POST['fat'];
        $rate = $_POST['rate'];
        $date = $_POST['date'];
        $session = $_POST['session'];


        $sql = "INSERT INTO milk(customer_id,qty,fat,rate,date,session) VALUES ('$customer_id','$qty','$fat','$rate','$date','$session')";
        $query = mysqli_query($con,$sql);
        if($query){
            echo "<script> alert('Data Inserted ')</script>";
        }
    }


    ?>

  <?php
include "footer.php";
  ?>