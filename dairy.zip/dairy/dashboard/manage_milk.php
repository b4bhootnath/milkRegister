<?php

include "header.php";
include "sidebar.php";
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Milk Management</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Milk Management</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Milk Management</h3>
                
                <div style="position: absolute;left: 150px;"> 
                    <a href="add_milk.php" class="btn btn-primary">Add Milk</a>
                </div>

              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>S. No.</th>
                    <th>Name</th>
                    <th>Father Name</th>
                    <th>Qty</th>
                    <th>Date</th>
                    <th>Session</th>
                    <th>Amount</th>
                    
                  </tr>
                  </thead>
                  <tbody>

                  <?php
                  $sno = 1;

                  $sql = "Select * From milk";
                  $result = mysqli_query($con,$sql);
                  if(mysqli_affected_rows($con) !=0){
                      while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
                          $qty = $row['qty'];
                          $fat = $row['fat'];
                          $rate = $row['rate'];
                          $date = $row['date'];
                          $session = $row['session'];
                          $am = (floatval($qty)*floatval($fat)*floatval($rate))/100;
                          $amount = round($am,2);





                          $customer_id = $row['customer_id'];
                          $query = mysqli_query($con,"Select * from customer where id='$customer_id'");
                          if(mysqli_affected_rows($con) !=0){
                              while($row2 = mysqli_fetch_array($query,MYSQLI_ASSOC)){
                                  $name = $row2['name'];
                                  $fname = $row2['fname'];

                              

                  ?>

                  <tr>
                      <td><?php echo $sno; ?></td>
                      <td><?php echo $name; ?></td>
                      <td><?php echo $fname; ?></td>
                      <td><?php echo $qty; ?></td>
                      <td><?php echo $date; ?></td>
                      <td><?php echo $session; ?></td>
                      <td>Rs. <?php echo $amount; ?></td>


                  </tr>



                <?php
                            }
                        }






                    $sno++;

                    }

                }

                ?>
                 
                  
                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>





      


      
          
            </div>
            </div>

        
        
        </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
    
  <?php
include "footer.php";
  ?>