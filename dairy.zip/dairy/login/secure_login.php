<?php
$a = $_SERVER['HTTP_REFERER'];

if (strpos($a, '/admin/') !== false) {
    
} else {
    header("Location: ../login/");
}

?>
<?php
include '../include/db_conn.php';

$user_id_auth = ltrim($_POST['user_id_auth']);
$user_id_auth = rtrim($user_id_auth);

$pass_key = ltrim($_POST['pass_key']);
$pass_key = rtrim($_POST['pass_key']);



$user_id_auth = mysqli_real_escape_string($con, $user_id_auth);
$pass_key     = mysqli_real_escape_string($con, $pass_key);


 $total_failed_login = 3;
    $lockout_time       = 15;
    $account_locked     = false;



$sql          = "SELECT * FROM admin WHERE email='$user_id_auth' and password='$pass_key'";
$result       = mysqli_query($con, $sql);
$count        = mysqli_num_rows($result);
if ($count == 1) {
    $row = mysqli_fetch_assoc($result);
    session_start();
    // store session data
    $_SESSION['user_data']  = $user_id_auth;
    $_SESSION['logged']     = "start";
    
    
    

    
    header("location: ../dashboard/");


    

        
} 
?>